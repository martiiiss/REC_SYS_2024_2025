import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
import scipy.sparse as sps
import matplotlib.pyplot as plt


class IncrementalSparseMatrix_ListBased(object):

    def __init__(self, auto_create_col_mapper = False, auto_create_row_mapper = False, n_rows = None, n_cols = None):

        super(IncrementalSparseMatrix_ListBased, self).__init__()

        self._row_list = []
        self._col_list = []
        self._data_list = []

        self._n_rows = n_rows
        self._n_cols = n_cols
        self._auto_create_column_mapper = auto_create_col_mapper
        self._auto_create_row_mapper = auto_create_row_mapper

        if self._auto_create_column_mapper:
            self._column_original_ID_to_index = {}

        if self._auto_create_row_mapper:
            self._row_original_ID_to_index = {}


    def add_data_lists(self, row_list_to_add, col_list_to_add, data_list_to_add):

        assert len(row_list_to_add) == len(col_list_to_add) and len(row_list_to_add) == len(data_list_to_add),\
            "IncrementalSparseMatrix: element lists must have different length"


        col_list_index = [self._get_column_index(column_id) for column_id in col_list_to_add]
        row_list_index = [self._get_row_index(row_id) for row_id in row_list_to_add]

        self._row_list.extend(row_list_index)
        self._col_list.extend(col_list_index)
        self._data_list.extend(data_list_to_add)




    def add_single_row(self, row_id, col_list, data = 1.0):

        n_elements = len(col_list)

        col_list_index = [self._get_column_index(column_id) for column_id in col_list]
        row_index = self._get_row_index(row_id)

        self._row_list.extend([row_index] * n_elements)
        self._col_list.extend(col_list_index)
        self._data_list.extend([data] * n_elements)



    def get_column_token_to_id_mapper(self):

        if self._auto_create_column_mapper:
            return self._column_original_ID_to_index.copy()



        dummy_column_original_ID_to_index = {}

        for col in range(self._n_cols):
            dummy_column_original_ID_to_index[col] = col

        return dummy_column_original_ID_to_index



    def get_row_token_to_id_mapper(self):

        if self._auto_create_row_mapper:
            return self._row_original_ID_to_index.copy()



        dummy_row_original_ID_to_index = {}

        for row in range(self._n_rows):
            dummy_row_original_ID_to_index[row] = row

        return dummy_row_original_ID_to_index



    def _get_column_index(self, column_id):

        if not self._auto_create_column_mapper:
            column_index = column_id

        else:

            if column_id in self._column_original_ID_to_index:
                column_index = self._column_original_ID_to_index[column_id]

            else:
                column_index = len(self._column_original_ID_to_index)
                self._column_original_ID_to_index[column_id] = column_index

        return column_index


    def _get_row_index(self, row_id):

        if not self._auto_create_row_mapper:
            row_index = row_id

        else:

            if row_id in self._row_original_ID_to_index:
                row_index = self._row_original_ID_to_index[row_id]

            else:
                row_index = len(self._row_original_ID_to_index)
                self._row_original_ID_to_index[row_id] = row_index

        return row_index


    def get_nnz(self):
        return len(self._row_list)



    def get_SparseMatrix(self):

        if self._n_rows is None:
            self._n_rows = max(self._row_list) + 1

        if self._n_cols is None:
            self._n_cols = max(self._col_list) + 1

        shape = (self._n_rows, self._n_cols)

        sparseMatrix = sps.csr_matrix((self._data_list, (self._row_list, self._col_list)), shape=shape)
        sparseMatrix.eliminate_zeros()


        return sparseMatrix





import numpy as np



class IncrementalSparseMatrix(IncrementalSparseMatrix_ListBased):

    def __init__(self, auto_create_col_mapper = False, auto_create_row_mapper = False, n_rows = None, n_cols = None, dtype = np.float64):

        super(IncrementalSparseMatrix, self).__init__(auto_create_col_mapper = auto_create_col_mapper,
                                                             auto_create_row_mapper = auto_create_row_mapper,
                                                             n_rows = n_rows,
                                                             n_cols = n_cols)

        self._dataBlock = 10000000
        self._next_cell_pointer = 0

        self._dtype_data = dtype
        self._dtype_coordinates = np.uint32
        self._max_value_of_coordinate_dtype = np.iinfo(self._dtype_coordinates).max

        self._row_array = np.zeros(self._dataBlock, dtype=self._dtype_coordinates)
        self._col_array = np.zeros(self._dataBlock, dtype=self._dtype_coordinates)
        self._data_array = np.zeros(self._dataBlock, dtype=self._dtype_data)


    def get_nnz(self):
        return self._next_cell_pointer


    def add_data_lists(self, row_list_to_add, col_list_to_add, data_list_to_add):

        assert len(row_list_to_add) == len(col_list_to_add) and len(row_list_to_add) == len(data_list_to_add),\
            "IncrementalSparseMatrix: element lists must have the same length"

        for data_point_index in range(len(row_list_to_add)):

            if self._next_cell_pointer == len(self._row_array):
                self._row_array = np.concatenate((self._row_array, np.zeros(self._dataBlock, dtype=self._dtype_coordinates)))
                self._col_array = np.concatenate((self._col_array, np.zeros(self._dataBlock, dtype=self._dtype_coordinates)))
                self._data_array = np.concatenate((self._data_array, np.zeros(self._dataBlock, dtype=self._dtype_data)))


            row_index = self._get_row_index(row_list_to_add[data_point_index])
            col_index = self._get_column_index(col_list_to_add[data_point_index])

            self._row_array[self._next_cell_pointer] = row_index
            self._col_array[self._next_cell_pointer] = col_index
            self._data_array[self._next_cell_pointer] = data_list_to_add[data_point_index]

            self._next_cell_pointer += 1




    def add_single_row(self, row_index, col_list, data = 1.0):

        n_elements = len(col_list)

        self.add_data_lists([row_index] * n_elements,
                            col_list,
                            [data] * n_elements)





    def get_SparseMatrix(self):

        if self._n_rows is None:
            self._n_rows = self._row_array.max() + 1

        if self._n_cols is None:
            self._n_cols = self._col_array.max() + 1

        shape = (self._n_rows, self._n_cols)

        sparseMatrix = sps.csr_matrix((self._data_array[:self._next_cell_pointer],
                                       (self._row_array[:self._next_cell_pointer], self._col_array[:self._next_cell_pointer])),
                                      shape=shape,
                                      dtype=self._dtype_data)

        sparseMatrix.eliminate_zeros()


        return sparseMatrix








class IncrementalSparseMatrix_FilterIDs(IncrementalSparseMatrix):
    """
    This class builds an IncrementalSparseMatrix allowing to constrain the row and column IDs that will be added
    It is useful, for example, when
    """

    def __init__(self, preinitialized_col_mapper = None, preinitialized_row_mapper = None,
                 on_new_col = "add", on_new_row = "add", dtype = np.float64):
        """
        Possible behaviour is:
        - Automatically add new ids:    if_new_col = "add" and predefined_col_mapper = None or predefined_col_mapper = {dict}
        - Ignore new ids                if_new_col = "ignore" and predefined_col_mapper = {dict}
        :param preinitialized_col_mapper:
        :param preinitialized_row_mapper:
        :param on_new_col:
        :param on_new_row:
        :param n_rows:
        :param n_cols:
        """

        super(IncrementalSparseMatrix_FilterIDs, self).__init__(dtype = dtype)

        self._row_list = []
        self._col_list = []
        self._data_list = []

        assert on_new_col in ["add", "ignore"], "IncrementalSparseMatrix: if_new_col value not recognized, allowed values are 'add', 'ignore', provided was '{}'".format(on_new_col)
        assert on_new_row in ["add", "ignore"], "IncrementalSparseMatrix: if_new_row value not recognized, allowed values are 'add', 'ignore', provided was '{}'".format(on_new_row)

        if on_new_col == "add":
            assert preinitialized_col_mapper is None or isinstance(preinitialized_col_mapper, dict), "IncrementalSparseMatrix: if on_new_col is 'add' then preinitialized_col_mapper must be either 'None' or contain a dictionary"

        if on_new_row == "add":
            assert preinitialized_row_mapper is None or isinstance(preinitialized_row_mapper, dict), "IncrementalSparseMatrix: if on_new_row is 'add' then preinitialized_row_mapper must be either 'None' or contain a dictionary"

        if on_new_col == "ignore":
            assert isinstance(preinitialized_col_mapper, dict), "IncrementalSparseMatrix: if on_new_col is 'ignore' then preinitialized_col_mapper must be a dictionary"

        if on_new_row == "ignore":
            assert isinstance(preinitialized_row_mapper, dict), "IncrementalSparseMatrix: if on_new_row is 'ignore' then preinitialized_row_mapper must be a dictionary"


        self._on_new_col_add_flag = on_new_col == "add"
        self._on_new_row_add_flag = on_new_row == "add"

        self._auto_create_row_mapper = True
        self._auto_create_column_mapper = True


        if preinitialized_col_mapper is None:
            self._column_original_ID_to_index = {}
        else:
            self._column_original_ID_to_index = preinitialized_col_mapper.copy()

        if preinitialized_row_mapper is None:
            self._row_original_ID_to_index = {}
        else:
            self._row_original_ID_to_index = preinitialized_row_mapper.copy()




    def _get_column_index(self, column_id):

        if column_id in self._column_original_ID_to_index:
            column_index = self._column_original_ID_to_index[column_id]

        elif self._on_new_col_add_flag:
            column_index = len(self._column_original_ID_to_index)
            self._column_original_ID_to_index[column_id] = column_index

        else:
            column_index = None

        return column_index




    def _get_row_index(self, row_id):

        if row_id in self._row_original_ID_to_index:
            row_index = self._row_original_ID_to_index[row_id]

        elif self._on_new_row_add_flag:
            row_index = len(self._row_original_ID_to_index)
            self._row_original_ID_to_index[row_id] = row_index

        else:
            row_index = None

        return row_index




    def add_data_lists(self, row_list_to_add, col_list_to_add, data_list_to_add):

        assert len(row_list_to_add) == len(col_list_to_add) and len(row_list_to_add) == len(data_list_to_add),\
            "IncrementalSparseMatrix: element lists must have different length"


        for data_point_index in range(len(row_list_to_add)):

            if self._next_cell_pointer == len(self._row_array):
                self._row_array = np.concatenate((self._row_array, np.zeros(self._dataBlock, dtype=self._dtype_coordinates)))
                self._col_array = np.concatenate((self._col_array, np.zeros(self._dataBlock, dtype=self._dtype_coordinates)))
                self._data_array = np.concatenate((self._data_array, np.zeros(self._dataBlock, dtype=self._dtype_data)))


            row_index = self._get_row_index(row_list_to_add[data_point_index])
            col_index = self._get_column_index(col_list_to_add[data_point_index])


            if row_index is not None and col_index is not None:

                self._row_array[self._next_cell_pointer] = row_index
                self._col_array[self._next_cell_pointer] = col_index
                self._data_array[self._next_cell_pointer] = data_list_to_add[data_point_index]

                self._next_cell_pointer += 1



    def get_SparseMatrix(self):

        # Set fixed dimension len to ensure that the matrix is not smaller than the number of entries in the dictionary
        self._n_rows = len(self._row_original_ID_to_index)
        self._n_cols = len(self._column_original_ID_to_index)


        return super(IncrementalSparseMatrix_FilterIDs, self).get_SparseMatrix()


def split_train_in_two_percentage_global_sample(URM_all, train_percentage = 0.1):
    """
    The function splits an URM in two matrices selecting the number of interactions globally
    :param URM_all:
    :param train_percentage:
    :param verbose:
    :return:
    """

    assert train_percentage >= 0.0 and train_percentage<=1.0, "train_percentage must be a value between 0.0 and 1.0, provided was '{}'".format(train_percentage)



    num_users, num_items = URM_all.shape

    URM_train_builder = IncrementalSparseMatrix(n_rows=num_users, n_cols=num_items, auto_create_col_mapper=False, auto_create_row_mapper=False)
    URM_validation_builder = IncrementalSparseMatrix(n_rows=num_users, n_cols=num_items, auto_create_col_mapper=False, auto_create_row_mapper=False)


    URM_train = sps.coo_matrix(URM_all)

    indices_for_sampling = np.arange(0, URM_all.nnz, dtype=np.int32)
    np.random.shuffle(indices_for_sampling)

    n_train_interactions = round(URM_all.nnz * train_percentage)

    indices_for_train = indices_for_sampling[indices_for_sampling[0:n_train_interactions]]
    indices_for_validation = indices_for_sampling[indices_for_sampling[n_train_interactions:]]


    URM_train_builder.add_data_lists(URM_train.row[indices_for_train],
                                     URM_train.col[indices_for_train],
                                     URM_train.data[indices_for_train])

    URM_validation_builder.add_data_lists(URM_train.row[indices_for_validation],
                                          URM_train.col[indices_for_validation],
                                          URM_train.data[indices_for_validation])


    URM_train = URM_train_builder.get_SparseMatrix()
    URM_validation = URM_validation_builder.get_SparseMatrix()

    URM_train = sps.csr_matrix(URM_train)
    URM_validation = sps.csr_matrix(URM_validation)

    user_no_item_train = np.sum(np.ediff1d(URM_train.indptr) == 0)
    user_no_item_validation = np.sum(np.ediff1d(URM_validation.indptr) == 0)

    if user_no_item_train != 0:
        print("Warning: {} ({:.2f} %) of {} users have no train items".format(user_no_item_train, user_no_item_train/num_users*100, num_users))
    if user_no_item_validation != 0:
        print("Warning: {} ({:.2f} %) of {} users have no sampled items".format(user_no_item_validation, user_no_item_validation/num_users*100, num_users))


    return URM_train, URM_validation
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------

#Split URM and ICM togheter (same samples!)
def split_train_in_two_percentage_global_sample(URM_all, ICM_all, train_percentage=0.8):
    """
    The function splits a URM and ICM in two matrices selecting the number of interactions globally.
    Applies the same sampling indices to both matrices.
    :param URM_all: User-Rating Matrix
    :param ICM_all: Item-Content Matrix
    :param train_percentage: float, percentage of data to use in training
    :return: URM_train, URM_validation, ICM_train, ICM_validation
    """
    assert 0.0 <= train_percentage <= 1.0, "train_percentage must be between 0.0 and 1.0, provided was '{}'".format(train_percentage)

    num_users, num_items = URM_all.shape

    # Set up builders for URM and ICM
    URM_train_builder = IncrementalSparseMatrix(n_rows=num_users, n_cols=num_items, auto_create_col_mapper=False, auto_create_row_mapper=False)
    URM_validation_builder = IncrementalSparseMatrix(n_rows=num_users, n_cols=num_items, auto_create_col_mapper=False, auto_create_row_mapper=False)
    
    # Similar setup for ICM if needed
    ICM_train_builder = IncrementalSparseMatrix(n_rows=num_users, n_cols=num_items, auto_create_col_mapper=False, auto_create_row_mapper=False)
    ICM_validation_builder = IncrementalSparseMatrix(n_rows=num_users, n_cols=num_items, auto_create_col_mapper=False, auto_create_row_mapper=False)

    # Convert URM to COO format for easy indexing
    URM_all_coo = sps.coo_matrix(URM_all)

    # Generate random indices for splitting
    indices_for_sampling = np.arange(URM_all.nnz, dtype=np.int32)
    np.random.shuffle(indices_for_sampling)

    n_train_interactions = round(URM_all.nnz * train_percentage)
    indices_for_train = indices_for_sampling[:n_train_interactions]
    indices_for_validation = indices_for_sampling[n_train_interactions:]

    # Add data to URM train/validation
    URM_train_builder.add_data_lists(URM_all_coo.row[indices_for_train], URM_all_coo.col[indices_for_train], URM_all_coo.data[indices_for_train])
    URM_validation_builder.add_data_lists(URM_all_coo.row[indices_for_validation], URM_all_coo.col[indices_for_validation], URM_all_coo.data[indices_for_validation])

    # Apply the same indices on the ICM matrix if desired
    if ICM_all is not None:
        ICM_all_coo = sps.coo_matrix(ICM_all)
        ICM_train_builder.add_data_lists(ICM_all_coo.row[indices_for_train], ICM_all_coo.col[indices_for_train], ICM_all_coo.data[indices_for_train])
        ICM_validation_builder.add_data_lists(ICM_all_coo.row[indices_for_validation], ICM_all_coo.col[indices_for_validation], ICM_all_coo.data[indices_for_validation])

    # Build final sparse matrices
    URM_train = sps.csr_matrix(URM_train_builder.get_SparseMatrix())
    URM_validation = sps.csr_matrix(URM_validation_builder.get_SparseMatrix())
    ICM_train = sps.csr_matrix(ICM_train_builder.get_SparseMatrix())
    ICM_validation = sps.csr_matrix(ICM_validation_builder.get_SparseMatrix())

    # Return both URM and ICM splits
    return URM_train, URM_validation, ICM_train, ICM_validation

#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------


# Carica il file CSV  -> URM
data = pd.read_csv('data_train.csv')

# Trova il massimo user_id e item_id per dimensionare correttamente la matrice
max_user_id = data['user_id'].max()
max_item_id = data['item_id'].max()

# Crea la matrice sparsa
URM_all = csr_matrix((data['data'], (data['user_id'], data['item_id'])), shape=(max_user_id + 1, max_item_id + 1))

# Print initial URM_train matrix
print("URM_all:")
print(URM_all)


# Carica il file CSV -> ICM
data_ICM = pd.read_csv('data_ICM_metadata.csv')

# Estrai le colonne necessarie
item_ids = data_ICM['item_id'].values
feature_ids = data_ICM['feature_id'].values
data_values = data_ICM['data'].values

# Trova il numero massimo di item_id e feature_id per determinare la dimensione della matrice
num_items = item_ids.max() + 1
num_features = feature_ids.max() + 1

# Crea la matrice ICM come matrice sparsa
ICM_matrix = sps.csr_matrix((data_values, (item_ids, feature_ids)), shape=(num_items, num_features))

# Print initial ICM matrix
print("\nICM_matrix:")
print(ICM_matrix)

# Verifica se ICM_matrix ha lo stesso numero di righe di URM_train, altrimenti riempie le righe mancanti ???
#if ICM_matrix.shape[0] < URM_train.shape[1]:
#    ICM_matrix = sps.vstack([ICM_matrix, sps.csr_matrix((URM_train.shape[1] - ICM_matrix.shape[0], ICM_matrix.shape[1]))])

# split the dataset into training set and validation set 
URM_train, URM_test, ICM_train, ICM_test = split_train_in_two_percentage_global_sample(URM_all, ICM_matrix, train_percentage=0.8)
print("\n URM_train:")
print(URM_train)
print("\n URM_test:")
print(URM_test)
print("\n ICM_train:")
print(ICM_train)
print("\n ICM_test:")
print(ICM_test)

#   EFFECTIVE ALGORITHM
from Recommenders.KNN.ItemKNN_CFCBF_Hybrid_Recommender import ItemKNN_CFCBF_Hybrid_Recommender

recommender_ItemKNNCFCBF = ItemKNN_CFCBF_Hybrid_Recommender(URM_train, ICM_matrix)
recommender_ItemKNNCFCBF.fit(ICM_weight = 1.0)



#Test on URM_test
for user_id in range(URM_test.shape[0]):
        # Get the top 10 recommendations for the user
        recommended_items = recommender_ItemKNNCFCBF.recommend(user_id_array=user_id, cutoff=10)
        print(f"User {user_id}: Recommended items {recommended_items}")
#####################################################################################################
            # ADD here the MAP computation on our splitted test set to choose the best hyperparameter!!
#####################################################################################################
        

# Print the predictions
trace_users = pd.read_csv('data_target_users_test.csv')
trace_users = trace_users.to_numpy()
# Open the file for writing recommendations
with open('sample_submission.csv', 'w') as file:
    
    file.write("user_id,item_list\n")
    # Loop over each user
    for user_id in trace_users:
        # Get the top 10 recommendations for the user
        recommended_items = recommender_ItemKNNCFCBF.recommend(user_id_array=user_id, cutoff=10)
        stringa=  (' '.join(map(str, np.array(recommended_items))))
        file.write(f"{user_id[0]}, {stringa[1: len(stringa) -1]}\n")
        
print("Recommendations have been written to 'sample_submission.csv'")


#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------


