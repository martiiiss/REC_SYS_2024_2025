import time
import numpy as np
import pandas as pd
from Data_manager.split_functions.split_train_validation_random_holdout import split_train_in_two_percentage_global_sample
from scipy.sparse import csr_matrix
import matplotlib.pyplot as plt

# Carica il file CSV
data = pd.read_csv('data_train.csv')

# Trova il massimo user_id e item_id per dimensionare correttamente la matrice
max_user_id = data['user_id'].max()
max_item_id = data['item_id'].max()

# Crea la matrice sparsa
URM_all = csr_matrix((data['data'], (data['user_id'], data['item_id'])), shape=(max_user_id + 1, max_item_id + 1))

# Suddividi in training e test
URM_train, URM_test = split_train_in_two_percentage_global_sample(URM_all, train_percentage=0.8)

# Conversione del training set in formato COO (Coordinate format)
URM_train_coo = URM_train.tocoo()
n_users, n_items = URM_train.shape
num_factors = 10
learning_rate = 1e-6    # Notare il basso learning rate
regularization = 1e-4   # Notare l'alto valore di regularizzazione

USER_profile_factors = np.random.random((n_items, num_factors))
ITEM_factors = np.random.random((n_items, num_factors))

num_epochs = 50  # Numero massimo di epoche
samples_per_epoch = 100000  # Numero di campioni per epoca
losses = []
map_scores = []

def calculate_map(URM_test, USER_profile_factors, ITEM_factors, top_k=10):
    map_score = 0.0
    num_users = URM_test.shape[0]
    
    # Campionamento di un sottoinsieme di utenti per velocizzare il calcolo
    sampled_users = np.random.choice(num_users, size=1000, replace=False)  # Scegli 1000 utenti a caso

    for user_id in sampled_users:
        user_profile = URM_test[user_id]
        if user_profile.nnz == 0:
            continue
            
        # Calcola la stima di rating per ogni item
        USER_estimated_factors = USER_profile_factors.dot(ITEM_factors.T).ravel()
        top_recommended_items = np.argsort(-USER_estimated_factors)[:top_k]
        
        # Ottieni gli item effettivamente valutati nel test set
        relevant_items = user_profile.indices
        if len(relevant_items) == 0:
            continue
        
        # Calcola la precision@k per questo utente
        hits = 0
        precision_sum = 0.0
        for rank, item_id in enumerate(top_recommended_items, start=1):
            if item_id in relevant_items:
                hits += 1
                precision_sum += hits / rank
        map_score += precision_sum / min(len(relevant_items), top_k)
    
    # Restituisci la media del MAP per gli utenti campionati
    return map_score / len(sampled_users) if len(sampled_users) > 0 else 0

for epoch in range(num_epochs):
    loss = 0.0
    start_time = time.time()
    print(f"Epoch {epoch+1}/{num_epochs}")
    
    for sample_num in range(samples_per_epoch):
        
        # Campionamento casuale
        sample_index = np.random.randint(URM_train_coo.nnz)
        user_id = URM_train_coo.row[sample_index]
        item_id = URM_train_coo.col[sample_index]
        rating = URM_train_coo.data[sample_index]
        
        # Calcolo della predizione
        user_profile = URM_train[user_id]
        
        if user_profile.nnz == 0:
            continue 
        
        USER_estimated_factors = user_profile.dot(USER_profile_factors).ravel() / np.sqrt(user_profile.nnz)
        predicted_rating = np.dot(USER_estimated_factors, ITEM_factors[item_id,:])
            
        # Errore di predizione
        prediction_error = rating - predicted_rating
        loss += prediction_error**2

        if np.isnan(loss):
            break 
        
        # Copia valori originali per evitare sovrascritture
        H_all = ITEM_factors.copy()
        W_all = USER_profile_factors.copy()
        
        # Applicazione degli aggiornamenti
        user_factors_update = prediction_error * user_profile.dot(H_all) - regularization * W_all
        item_factors_update = prediction_error * user_profile.dot(W_all) - regularization * H_all
        
        USER_profile_factors += learning_rate * user_factors_update 
        ITEM_factors += learning_rate * item_factors_update
    
    # Calcola la MAP sul set di test alla fine di ogni epoca
    map_score = calculate_map(URM_test, USER_profile_factors, ITEM_factors)
    map_scores.append(map_score)
    
    # Salva la perdita alla fine di ogni epoca
    losses.append(loss)
    print(f"Epoch {epoch+1}/{num_epochs} - Loss: {loss:.4f}  - Time: {time.time() - start_time:.2f}s")

# Plot della loss e MAP
plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
plt.plot(losses, label="Loss")
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.title("Loss per Epoch")

plt.subplot(1, 2, 2)
plt.plot(map_scores, label="MAP", color="orange")
plt.xlabel("Epoch")
plt.ylabel("MAP")
plt.title("MAP per Epoch")

plt.tight_layout()
plt.show()