import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
import scipy.sparse as sps
import matplotlib.pyplot as plt

from Data_manager.split_functions.split_train_validation_random_holdout import split_train_in_two_percentage_global_sample
from Recommenders.BaseRecommender import BaseRecommender
class ScoresHybridRecommender(BaseRecommender):
    """ ScoresHybridRecommender
    Hybrid of two prediction scores R = R1*alpha + R2*(beta) +R3*(1-alpha-beta)

    """

    RECOMMENDER_NAME = "ScoresHybridRecommender"

    def __init__(self, URM_train):
        super(ScoresHybridRecommender, self).__init__(URM_train)

        self.URM_train = sps.csr_matrix(URM_train)
        """
        self.recommender_1 = recommender_1
        self.recommender_2 = recommender_2
        self.recommender_3 = recommender_3
        #self.recommender_4 = recommender_4
        """
    def fit(self, alpha=0.3):
        self.alpha = alpha      
        
        #self.gamma= gamma
    def _compute_item_score(self, user_id_array, items_to_compute):
        """
        # In a simple extension this could be a loop over a list of pretrained recommender objects
        item_weights_1 = self.recommender_1._compute_item_score(user_id_array)
        item_weights_2 = self.recommender_2._compute_item_score(user_id_array)
        item_weights_3 = self.recommender_3._compute_item_score(user_id_array)
        #item_weights_4 = self.recommender_4._compute_item_score(user_id_array)
        """
        item_weights =train_multiple_epochs(URM_train, 1e-4, 10)
        
        return item_weights
    

# Carica il file CSV  -> URM
data = pd.read_csv('data_train.csv')

# Trova il massimo user_id e item_id per dimensionare correttamente la matrice
max_user_id = data['user_id'].max()
max_item_id = data['item_id'].max()

# Crea la matrice sparsa
URM_all = csr_matrix((data['data'], (data['user_id'], data['item_id'])), shape=(max_user_id + 1, max_item_id + 1))
URM_train, URM_test = split_train_in_two_percentage_global_sample(URM_all, train_percentage=0.8)

import numpy as np
from scipy.sparse import csr_matrix

from slim_cython import train_multiple_epochs

scoreshybridrecommender = ScoresHybridRecommender(URM_train)
scoreshybridrecommender.fit( )
from Evaluation.Evaluator import EvaluatorHoldout
cutoff_list=[10]

evaluator_validation = EvaluatorHoldout(URM_all, cutoff_list=cutoff_list)
result_df, _ = evaluator_validation.evaluateRecommender(scoreshybridrecommender)
print(result_df)



print("Recommendations have been written to 'sample_submission.csv'")