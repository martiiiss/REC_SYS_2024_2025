import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
import scipy.sparse as sps
import matplotlib.pyplot as plt

from Data_manager.split_functions.split_train_validation_random_holdout import split_train_in_two_percentage_global_sample
from Recommenders.NonPersonalizedRecommender import TopPop
from Recommenders.KNN.UserKNNCFRecommender import UserKNNCFRecommender
from Recommenders.KNN.ItemKNNCFRecommender import ItemKNNCFRecommender
from Recommenders.GraphBased.P3alphaRecommender import P3alphaRecommender
from Recommenders.GraphBased.RP3betaRecommender import RP3betaRecommender
from Recommenders.MatrixFactorization.PureSVDRecommender import PureSVDRecommender
from Recommenders.MatrixFactorization.IALSRecommender import IALSRecommender
from Recommenders.MatrixFactorization.NMFRecommender import NMFRecommender

# Carica il file CSV  -> URM
data = pd.read_csv('data_train.csv')

# Trova il massimo user_id e item_id per dimensionare correttamente la matrice
max_user_id = data['user_id'].max()
max_item_id = data['item_id'].max()

# Crea la matrice sparsa
URM_all = csr_matrix((data['data'], (data['user_id'], data['item_id'])), shape=(max_user_id + 1, max_item_id + 1))
URM_train, URM_test = split_train_in_two_percentage_global_sample(URM_all, train_percentage=0.8)

# Print initial URM_train matrix
#print("URM_train (before concatenation):")
#print(URM_train)


# Carica il file CSV -> ICM
data_ICM = pd.read_csv('data_ICM_metadata.csv')

# Estrai le colonne necessarie
item_ids = data_ICM['item_id'].values
feature_ids = data_ICM['feature_id'].values
data_values = data_ICM['data'].values

# Trova il numero massimo di item_id e feature_id per determinare la dimensione della matrice
num_items = item_ids.max() + 1
num_features = feature_ids.max() + 1

# Crea la matrice ICM come matrice sparsa
ICM_matrix = sps.csr_matrix((data_values, (item_ids, feature_ids)), shape=(num_items, num_features))

# Print initial ICM matrix
#print("\nICM_matrix (before concatenation):")
#print(ICM_matrix)

# Verifica se ICM_matrix ha lo stesso numero di righe di URM_train, altrimenti riempie le righe mancanti
if ICM_matrix.shape[0] < URM_train.shape[1]:
    ICM_matrix = sps.vstack([ICM_matrix, sps.csr_matrix((URM_train.shape[1] - ICM_matrix.shape[0], ICM_matrix.shape[1]))])

# Concatenate URM and ICM
stacked_URM = sps.vstack([URM_all, ICM_matrix.T])
stacked_URM = sps.csr_matrix(stacked_URM)

# Print the concatenated stacked_URM matrix
print("\nstacked_URM (after concatenation):")
#print(stacked_URM)

from Recommenders.BaseRecommender import BaseRecommender

class ScoresHybridRecommender(BaseRecommender):
    """ ScoresHybridRecommender
    Hybrid of two prediction scores R = R1*alpha + R2*(beta) +R3*(1-alpha-beta)

    """

    RECOMMENDER_NAME = "ScoresHybridRecommender"

    def __init__(self, URM_train, recommender_1, recommender_2,recommender_3,recommender_4,recommender_5,recommender_6):
        super(ScoresHybridRecommender, self).__init__(URM_train)

        self.URM_train = sps.csr_matrix(URM_train)
        self.recommender_1 = recommender_1
        self.recommender_2 = recommender_2
        self.recommender_3 = recommender_3
        self.recommender_4 = recommender_4
        self.recommender_5 = recommender_5
        self.recommender_6 = recommender_6
    def fit(self, alpha = 0.3, beta= 0.3, gamma= 0.2, theta=0.1, omega=0.1):
        self.alpha = alpha      
        self.beta = beta
        self.gamma= gamma
        self.theta= theta
        self.omega= omega
    def _compute_item_score(self, user_id_array, items_to_compute):
        
        # In a simple extension this could be a loop over a list of pretrained recommender objects
        item_weights_1 = self.recommender_1._compute_item_score(user_id_array)
        item_weights_2 = self.recommender_2._compute_item_score(user_id_array)
        item_weight_3= self.recommender_3._compute_item_score(user_id_array)
        item_weight_4= self.recommender_4._compute_item_score(user_id_array)
        item_weight_5= self.recommender_5._compute_item_score(user_id_array)
        item_weight_6 = self.recommender_6._compute_item_score(user_id_array)
        item_weights = item_weights_1*self.alpha + item_weights_2*(self.beta) + item_weight_3*( self.gamma) +item_weight_4*(self.theta) +item_weight_5*(self.omega) +item_weight_6*(1-self.beta- self.alpha - self.gamma -self.theta -self.omega)

        return item_weights
    
from Recommenders.MatrixFactorization.PureSVDRecommender import PureSVDRecommender
from Recommenders.KNN.ItemKNNCustomSimilarityRecommender import ItemKNNCustomSimilarityRecommender
from Recommenders.KNN.ItemKNNCFRecommender import ItemKNNCFRecommender
from Recommenders.KNN.ItemKNN_CFCBF_Hybrid_Recommender import ItemKNN_CFCBF_Hybrid_Recommender
from Evaluation.Evaluator import EvaluatorHoldout
from Recommenders.KNN.ItemKNNCFRecommender import ItemKNNCFRecommender
from Recommenders.KNN.ItemKNNCBFRecommender import ItemKNNCBFRecommender
from Recommenders.KNN.ItemKNNCFRecommender import ItemKNNCFRecommender

cutoff_list=[10]

evaluator_validation = EvaluatorHoldout(URM_all, cutoff_list=cutoff_list)

pureSVD = PureSVDRecommender(URM_train)
pureSVD.fit()

itemKNNCF = ItemKNNCFRecommender(URM_train)
itemKNNCF.fit()

recommender_ItemKNNCFCBF = ItemKNN_CFCBF_Hybrid_Recommender(URM_train, ICM_matrix)
recommender_ItemKNNCFCBF.fit(ICM_weight = 2.0)

recommender_ItemKNNCF = ItemKNNCFRecommender(stacked_URM)
recommender_ItemKNNCF.fit()

recommeder_ItemKNNCBF= ItemKNNCBFRecommender(URM_train,ICM_matrix)
recommeder_ItemKNNCBF.fit()

TopPop_recommender= TopPop(URM_train)
TopPop_recommender.fit()

scoreshybridrecommender = ScoresHybridRecommender(URM_train, itemKNNCF, pureSVD,recommender_ItemKNNCFCBF, TopPop_recommender,recommender_ItemKNNCF,recommeder_ItemKNNCBF)
for alpha_par in range(11):
    alpha_par_1= alpha_par /10
    for beta_par in range(11- alpha_par):
        beta_par_1 = beta_par/10
        for gamma_par in range(11-beta_par):
            gamma_par_1= gamma_par/10
            for theta_par in range(11- gamma_par):
                theta_par_1= theta_par /10
                for omega_par in range(11- theta_par):
                    omega_par_1= omega_par/10
                    print(f"alpha = {alpha_par_1}, beta = {beta_par_1}, gamma ={gamma_par_1}, theta = {theta_par_1}, omega ={omega_par_1}")
                    scoreshybridrecommender.fit(alpha = alpha_par_1,beta= beta_par_1,gamma= gamma_par_1,theta = theta_par_1, omega=omega_par_1)
                    result_df, _ = evaluator_validation.evaluateRecommender(scoreshybridrecommender)
                    print(result_df)
